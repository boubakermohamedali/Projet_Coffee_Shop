-- MySQL dump 10.16  Distrib 10.1.48-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.1.48-MariaDB-0+deb9u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dbo.ENTCOM`
--

DROP TABLE IF EXISTS `dbo.ENTCOM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.ENTCOM` (
  `NUMCOM` tinyint(4) DEFAULT NULL,
  `OBSCOM` varchar(17) DEFAULT NULL,
  `DATCOM` varchar(19) DEFAULT NULL,
  `NUMFOU` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.ENTCOM`
--

LOCK TABLES `dbo.ENTCOM` WRITE;
/*!40000 ALTER TABLE `dbo.ENTCOM` DISABLE KEYS */;
INSERT INTO `dbo.ENTCOM` VALUES (1,'','2007-02-10 00:00:00',120),(3,'','2007-04-25 00:00:00',9180),(4,'Commande urgente','2007-04-30 00:00:00',9150),(5,'Commande cadencéé','2007-05-05 00:00:00',120),(6,'','2007-06-06 00:00:00',9120),(7,'Commande cadencée','2007-10-02 00:00:00',8700),(9,'','2007-10-09 00:00:00',120),(10,'','2007-10-12 00:00:00',9180);
/*!40000 ALTER TABLE `dbo.ENTCOM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.FOURNIT`
--

DROP TABLE IF EXISTS `dbo.FOURNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.FOURNIT` (
  `NUMFOU` varchar(4) DEFAULT NULL,
  `NOMFOU` varchar(9) DEFAULT NULL,
  `RUEFOU` varchar(25) DEFAULT NULL,
  `POSFOU` varchar(5) DEFAULT NULL,
  `VILFOU` varchar(16) DEFAULT NULL,
  `CONFOU` varchar(7) DEFAULT NULL,
  `SATISF` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.FOURNIT`
--

LOCK TABLES `dbo.FOURNIT` WRITE;
/*!40000 ALTER TABLE `dbo.FOURNIT` DISABLE KEYS */;
INSERT INTO `dbo.FOURNIT` VALUES ('120','GROBRIGAN','20 rue du papier','92200','papercity','Georges','8'),('8700','MEDICIS','120 rue des plantes','75014','Paris','Lison',''),('9120','DISCOBOL','11 rue des sports','85100','La roche sur Yon','Hercule','8'),('9150','DEPANPAP','26, avenue des locomotive','59987','Coroncountry','Pollux','5'),('9180','HURRYTAPE','68, boulevard des octets','04044','Dumpville','Track',''),('','Bon','','','','','');
/*!40000 ALTER TABLE `dbo.FOURNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.LIGCOM`
--

DROP TABLE IF EXISTS `dbo.LIGCOM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.LIGCOM` (
  `NUMCOM` tinyint(4) DEFAULT NULL,
  `CODART` varchar(4) DEFAULT NULL,
  `NUMLIG` tinyint(4) DEFAULT NULL,
  `QTECDE` mediumint(9) DEFAULT NULL,
  `PRIUNI` smallint(6) DEFAULT NULL,
  `QTELIV` mediumint(9) DEFAULT NULL,
  `DERLIV` varchar(19) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.LIGCOM`
--

LOCK TABLES `dbo.LIGCOM` WRITE;
/*!40000 ALTER TABLE `dbo.LIGCOM` DISABLE KEYS */;
INSERT INTO `dbo.LIGCOM` VALUES (1,'D035',4,200,40,250,'2007-02-20 00:00:00'),(1,'l100',1,3000,470,3000,'2007-03-15 00:00:00'),(1,'l105',2,2000,485,2000,'2007-07-05 00:00:00'),(1,'l108',3,1000,680,1000,'2007-08-20 00:00:00'),(1,'P220',5,6000,3500,6000,'2007-03-31 00:00:00'),(1,'P240',6,6000,2000,2000,'2007-03-31 00:00:00'),(3,'B001',1,200,140,0,'2007-12-31 00:00:00'),(3,'B002',2,200,140,0,'2007-12-31 00:00:00'),(4,'l100',1,1000,590,1000,'2007-05-15 00:00:00'),(4,'l105',2,500,590,500,'2007-05-15 00:00:00'),(5,'l100',1,1000,470,1000,'2007-07-15 00:00:00'),(5,'P220',2,10000,3500,10000,'2007-08-31 00:00:00'),(6,'l110',1,50,790,50,'2007-10-31 00:00:00'),(7,'P220',2,10000,3350,10000,'2007-11-10 00:00:00'),(7,'P230',1,15000,4900,12000,'2007-12-15 00:00:00'),(9,'l100',1,1000,470,1000,'2007-10-15 00:00:00'),(9,'P220',2,10000,3500,10000,'2007-10-31 00:00:00'),(10,'B001',1,200,140,0,'2007-12-31 00:00:00'),(10,'B002',2,200,140,0,'2007-12-31 00:00:00');
/*!40000 ALTER TABLE `dbo.LIGCOM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.PRODUIT`
--

DROP TABLE IF EXISTS `dbo.PRODUIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.PRODUIT` (
  `CODART` varchar(4) DEFAULT NULL,
  `LIBART` varchar(25) DEFAULT NULL,
  `STKALE` smallint(6) DEFAULT NULL,
  `STKPHY` smallint(6) DEFAULT NULL,
  `QTEANN` mediumint(9) DEFAULT NULL,
  `UNIMES` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.PRODUIT`
--

LOCK TABLES `dbo.PRODUIT` WRITE;
/*!40000 ALTER TABLE `dbo.PRODUIT` DISABLE KEYS */;
INSERT INTO `dbo.PRODUIT` VALUES ('B001','Bande magnétique 1200',20,87,240,'unité'),('B002','Bande magnétique 6250',20,12,410,'unité'),('D035','CD R slim 80 mm',40,42,150,'B010'),('D050','CD R-W 80 mm',50,4,0,'B010'),('l100','Papier 1 ex continu',100,557,3500,'B1000'),('l105','Papier 2 ex continu',75,5,2300,'B1000'),('l108','Papier 3 ex continu',200,557,3500,'B500'),('l110','Papier 4 ex continu',10,12,63,'B400'),('P220','Pré imprimé commande',500,2500,24500,'B500'),('P230','Pré imprimé facture',500,250,12500,'B500'),('P240','Pré imprimé bulletin paie',500,3000,6250,'B500'),('P250','Pré imprimé livraison',500,2500,24500,'B500'),('P270','Pré imprimé fabrication',500,2500,24500,'B500'),('R080','Ruban Epson 850',10,2,120,'unité'),('R132','Ruban imp1200 lignes',25,200,182,'unité');
/*!40000 ALTER TABLE `dbo.PRODUIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.VENTE`
--

DROP TABLE IF EXISTS `dbo.VENTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.VENTE` (
  `CODART` varchar(4) DEFAULT NULL,
  `NUMFOU` smallint(6) DEFAULT NULL,
  `DELLIV` tinyint(4) DEFAULT NULL,
  `QTE1` tinyint(4) DEFAULT NULL,
  `PRIX1` smallint(6) DEFAULT NULL,
  `QTE2` varchar(3) DEFAULT NULL,
  `PRIX2` varchar(5) DEFAULT NULL,
  `QTE3` varchar(3) DEFAULT NULL,
  `PRIX3` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.VENTE`
--

LOCK TABLES `dbo.VENTE` WRITE;
/*!40000 ALTER TABLE `dbo.VENTE` DISABLE KEYS */;
INSERT INTO `dbo.VENTE` VALUES ('B001',8700,15,0,150,'50','14000','100','140'),('B002',8700,15,0,210,'50','200','100','185'),('D035',120,0,0,40,'','','',''),('D035',9120,5,0,40,'100','30','',''),('l100',120,90,0,700,'50','600','120','500'),('l100',9120,60,0,800,'70','600','90','500'),('l100',9150,90,0,650,'90','600','200','590'),('l100',9180,30,0,720,'50','670','100','490'),('l105',120,90,10,705,'50','630','120','500'),('l105',8700,30,0,720,'50','670','100','510'),('l105',9120,60,0,920,'70','800','90','700'),('l105',9150,90,0,685,'90','600','200','590'),('l108',120,90,5,795,'30','720','100','680'),('l108',9120,60,0,920,'70','820','100','780'),('l110',9120,60,0,950,'70','850','90','790'),('l110',9180,90,0,900,'70','870','90','835'),('P220',120,15,0,3700,'100','3500','',''),('P220',8700,20,50,3500,'100','3350','',''),('P230',120,30,0,5200,'100','5000','',''),('P230',8700,60,0,5000,'50','4900','',''),('P240',120,15,0,2200,'100','2000','',''),('P250',120,30,0,1500,'100','14000','500','1200'),('P250',9120,30,0,1500,'100','14000','500','1200'),('R080',9120,10,0,120,'100','14000','',''),('R132',9120,5,0,275,'','','','');
/*!40000 ALTER TABLE `dbo.VENTE` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-27 22:44:46
